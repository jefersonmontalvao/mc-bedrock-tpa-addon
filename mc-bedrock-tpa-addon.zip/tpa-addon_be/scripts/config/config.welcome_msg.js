const WelcomeMessage = "Bem Vindo(a) Ao Servidor!"

export { WelcomeMessage }