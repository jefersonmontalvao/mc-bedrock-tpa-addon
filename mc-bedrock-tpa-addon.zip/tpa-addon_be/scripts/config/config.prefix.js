const CommandPrefix = '!'

export { CommandPrefix }