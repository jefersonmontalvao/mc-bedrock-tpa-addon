// UI Text
const ChooseTargetPlayerMessage = "Escolha um jogador alvo"
const GoOrComeToggleButtom = "Ative para trazer um jogador até você\nDesative para ir até um jogador"
const UiTittle = "§8§lTPA§r"
const BodyTittle = "§7§lTPA : §r"
const RequestToTakeYouToRequesterLocation = "quer teleportar você para sua localização"
const RequestToGoToTargetLocation = "quer se teleportar para a sua localização"
const AcceptOrDenyButtom = {yes: "Aceitar", no: "Recusar"}

// UI Chat Advice
const NewRequestAdvice = "[§8Tpa System§r] : Você enviou uma solicitação para "
const TeleportDoneCorreclyAdvice = "[§8Tpa System§r] : Teleportado com sucesso"
const CanceledRequestAdvice = "[§8Tpa System§r] : Solicitação cancelada"

export { ChooseTargetPlayerMessage, GoOrComeToggleButtom, UiTittle, BodyTittle, RequestToGoToTargetLocation, RequestToTakeYouToRequesterLocation, AcceptOrDenyButtom, NewRequestAdvice, TeleportDoneCorreclyAdvice, CanceledRequestAdvice}
