const CreditsMessage = "§f[§8Tpa System§f] : Thanks for downloading, courtesy of §o§7LuCiferKun6582§r."

export { CreditsMessage }
